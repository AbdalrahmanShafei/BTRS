﻿using System.ComponentModel.DataAnnotations;


namespace BTRS.Models
{
    public class Admin
    {
        [Key]
        public int ID { get; set; }
        [Required]
        public string username { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        [Required]
        public string FullName { get; set; }

        public ICollection<Trip> Trips { get; set; }
        public ICollection<Bus>buses { get; set; }



    }
}
