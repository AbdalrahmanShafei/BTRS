﻿using Microsoft.EntityFrameworkCore;
using BTRS.Models;
using Microsoft.EntityFrameworkCore;
using BTRS.Models;

namespace BTRS.Models
{
    public class SystemDbContext : DbContext


    {

        public SystemDbContext(DbContextOptions<SystemDbContext> options) : base(options) { }


        public DbSet<Passenger> Passengers { get; set; }
        public DbSet<Bus> Buses { get; set; }
        public DbSet<Trip> Trips { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Admin> Admins { get; set; }


    }
}



