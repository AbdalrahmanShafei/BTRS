﻿using System.ComponentModel.DataAnnotations.Schema;

namespace BTRS.Models
{
    public class Booking
    {
        public int BookingId { get; set; }

        //public int PassengerId { get; set; }
        [ForeignKey("PassengerId")]
        public Passenger ?Passenger { get; set; }


        //public int TripId { get; set; }
        [ForeignKey("TripId")]
        public Trip ?trip { get; set; }

    }
}
