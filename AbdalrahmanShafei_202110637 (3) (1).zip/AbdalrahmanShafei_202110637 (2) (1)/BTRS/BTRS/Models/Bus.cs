﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BTRS.Models
{
    public class Bus
    {
        public int BusId { get; set; }

        public string CaptainName { get; set; }

        public int NumberOfSeats { get; set; }

      

        public ICollection<Booking> Bookings { get; set; }

        //public int AdminId { get; set; }

         [ForeignKey("AdminId")]
        public Admin ?admin { get; set; }


        //public int TripId { get; set; }

        [ForeignKey("TripId")]
        public Trip ?trip { get; set; }






    }
}


    