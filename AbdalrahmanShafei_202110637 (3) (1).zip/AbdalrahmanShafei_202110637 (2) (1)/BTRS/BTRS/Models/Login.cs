﻿using System.ComponentModel.DataAnnotations;

namespace BTRS.Models
{
    public class Login
    {
        [Key]
        public int Id {  get; set; }

        [Required(ErrorMessage ="Please fill the username")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Please fill the password")]

        public string Password { get; set; }
    }
}
