﻿using BTRS.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;

namespace BTRS_MID.Controllers
{
    public class TripController : Controller

    {
        private readonly SystemDbContext _context;

        public TripController(SystemDbContext context)
        {
            _context = context;
        }

        public ActionResult Index()
        {
            // Fetch data from the database or other source
            //List<Trip> trips = _context.Trips.ToList();


            //var trips = _context.Trips.ToList(); // Retrieve trips from the database

            return View(_context.Trips.ToList());






            // GET: TripController
            //    public ActionResult Index()
            //{
        }

        // GET: TripController/Details/5
        public ActionResult Details(int id)
        {

            Trip trips = _context.Trips.Find(id);


            return View(trips);
        }

        // GET: TripController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: TripController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]



        public ActionResult Create(Trip trips)
        {
            try
            {

                int adminID = int.Parse(HttpContext.Session.GetString("adminid"));

                Admin admin = _context.Admins.Where(a => a.ID == adminID).FirstOrDefault();

                trips.admin = admin;



                _context.Trips.Add(trips);
                _context.SaveChanges();


                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: TripController/Edit/5
        public ActionResult Edit(int id)
        {

            Trip trip = _context.Trips.Find(id);

            return View(trip);
        }

        // POST: TripController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Trip trip)
        {
            try
            {

                int adminID = int.Parse(HttpContext.Session.GetString("adminid"));

                Admin admin = _context.Admins.Where(a => a.ID == adminID).FirstOrDefault();

                trip.admin = admin;



                //_context.Attach(trip); // Attach the entity to the context
                //_context.Entry(trip).State = EntityState.Modified; // Mark the entity as modified
                //_context.SaveChanges();

                _context.Trips.Update(trip);
                _context.SaveChanges();

                return RedirectToAction(nameof(Index));
            }

            catch
            {
                return View();
            }
        }

        // GET: TripController/Delete/5
        public ActionResult Delete(int id)
        {
            Trip trip = _context.Trips.Find(id);

            // Check if the trip exists
            if (trip == null)
            {
                return NotFound();
            }

            return View(trip);
        }

        // POST: TripController/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Trip trip = _context.Trips.Find(id);

            // Check if the trip exists
            if (trip == null)
            {
                return NotFound();
            }

            _context.Trips.Remove(trip);
            _context.SaveChanges();

            return RedirectToAction(nameof(Index));
        }

        






    }
}