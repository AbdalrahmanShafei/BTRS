﻿using BTRS.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using System.Runtime.Intrinsics.X86;
using System.Security.Cryptography.X509Certificates;

namespace BTRS_MID.Controllers
{
    public class PassengerController : Controller
    {

        private SystemDbContext _context;

        public PassengerController(SystemDbContext context)
        {
            this._context = context;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(Passenger SignUp)
        {
            SignUp.Id = 0;

            bool empty = checkEmpty(SignUp);
            bool duplicate = checkEmail(SignUp.Email);


            //bool duplicates = checkUsername(SignUp.Username);
            //bool duplicatees = checkPhonenumber(SignUp.PhoneNumber);


            if (empty)
            {
                if (duplicate)
                {
                    _context.Passengers.Add(SignUp);
                    _context.SaveChanges();
                    TempData["Msg"] = "the data was saved";

                    return View();
                }
                else
                {
                    TempData["Msg"] = "Email address is already in use.Please choose another.";

                    return View();

                }
            }

            else
            {
                return View();
            }
        }

        public bool checkEmpty(Passenger passenger)
        {
            if (string.IsNullOrEmpty(passenger.Username)) return false;
            else if (string.IsNullOrEmpty(passenger.Password)) return false;
            else if (string.IsNullOrEmpty(passenger.Email)) return false;
            else if (string.IsNullOrEmpty(passenger.PhoneNumber)) return false;
            else if (string.IsNullOrEmpty(passenger.Name)) return false;
            else return true;

        }
        public bool checkEmail(string Email)
        {
            Passenger passenger = _context.Passengers.Where(e => e.Email.Equals(Email)).FirstOrDefault();

            if (passenger != null)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(Login login)
        {
            if (!ModelState.IsValid)
            {
                return View(login);
            }

            string username = login.Username;
            string password = login.Password;

            Passenger passenger=_context.Passengers
                .FirstOrDefault(u => u.Username.Equals(username) && u.Password.Equals(password));

            Admin admin=_context.Admins
                .FirstOrDefault(u => u.username.Equals(username) && u.Password.Equals(password));





            if (passenger != null)
            {
                // Successful login, redirect to "TripList"

                HttpContext.Session.SetString("Passengerid", passenger.Id.ToString());

                return RedirectToAction("TripList");
            }


            //Admin
            else if (admin != null)
            {
                HttpContext.Session.SetString("adminid", admin.ID.ToString());
                return RedirectToAction("Index", "Trip");
            }
            else
            {
                TempData["Msg"] = "The user not Found";
                return View();
            }
        }



        [HttpGet]
        public IActionResult TripList()
        {
            return View(_context.Trips.ToList());
        }
        public IActionResult Book(int id)
        {
            int TripId = id;
            string PassengerId = HttpContext.Session.GetString("Passengerid");

            Booking booking = new Booking();

            // Ensure PassengerId is not null before attempting to find the Passenger
            if (!string.IsNullOrEmpty(PassengerId))
            {
                // Parse the string to int if needed (assuming PassengerId is an int)
                // If PassengerId is already an int, you can skip the parsing
                int parsedPassengerId;
                if (int.TryParse(PassengerId, out parsedPassengerId))
                {
                    booking.Passenger = _context.Passengers.Find(parsedPassengerId);
                    booking.trip = _context.Trips.Find(TripId);

                    _context.Bookings.Add(booking);
                    _context.SaveChanges();

                    return RedirectToAction("BookList"); // This is the return statement for the successful path
                }
                else
                {
                    // Handle the case when parsing fails
                    // Log or return an error response
                    return BadRequest("Invalid PassengerId");
                }
            }
            else
            {
                // Handle the case when PassengerId is null or empty
                // Log or return an error response
                return BadRequest("PassengerId is missing");
            }
        }

        public IActionResult BookList()
        {
            string PassengerId = HttpContext.Session.GetString("Passengerid");

            List<int> lst_trip = _context.Bookings
    .Where(b => b.Passenger.Id == int.Parse(PassengerId))
    .Select(b => b.trip.TripId)
    .ToList();

            List<Trip> lst = _context.Trips
                .Where(t => lst_trip.Contains(t.TripId))
                .ToList();

            return View(lst);
        }
    }
}  











